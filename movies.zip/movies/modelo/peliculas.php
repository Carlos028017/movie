<?php
require_once 'ORM.php';
class Peliculas extends orm{
    public function __construct(PDO $connection) {
        parent::__construct('id','peliculas', $connection);
    }

}