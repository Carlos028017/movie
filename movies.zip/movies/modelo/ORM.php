<?php
require_once '../modelo/conexion.php';

class orm{
    
    protected $id;
    protected $tabla;
    protected $db;
    public function __construct($id, $tabla, $db) {
        $this->id = $id;
        $this->tabla= $tabla;
        $this->db = new film();
    }


    public function getAll(){
        $sql = $this->db->prepare("SELECT * FROM {$this->tabla}");
        $sql->execute();
    }

    public function getById($id){
        
        $sql = $this->db->prepare("SELECT * FROM {$this->tabla} where id = {$this->id}");
        $sql->execute();
        return $sql->fetchAll();
    }

    public function deleteById($id){
        $sql = $this->db->prepare("SELECT * FROM {$this->tabla} where id = {$this->id}");
        $sql->execute();
    }

    public function updateById($id, $data){
        $sql= "UPDATE {$this->tabla} SET";
        foreach($data as $key => $value){
            $sql .="{$key} = :{$key}"; 
        }
        $sql = trim($sql,",");
        $sql .="WHERE id= :id"; 

        $stm= $this->db->prepare($sql);
        foreach($data as $key => $value){
            $stm->bindValue(":{$key}",$value);
        }
        $stm->bindValue("id",$id);
        $stm->execute();
    }

    public function insert($data){
        $sql= "INSERT INTO {$this->tabla} (";
        foreach($data as $key => $value){
            $sql .="{$key}"; 
        }
        $sql = trim($sql,",");
        $sql .=") VALUES ("; 

        foreach($data as $key => $value){
            $sql .="{$key}"; 
        }
        $sql = trim($sql,",");
        $sql .=")"; 

        $stm= $this->db->prepare($sql);
        foreach($data as $key => $value){
            $stm->bindValue(":{$key}",$value);
        }
        
        $stm->execute();
    }
}