<?php

namespace Controlador;

require_once 'modelo/api.php';

use Modelo\Peliculas;

class Eliminar {

    private $modelo;

    public function __construct() {
        $this->modelo = new Peliculas(); // Inicializa el modelo 
    }

    public function eliminar($apiKey) {
        $movies = $this->modelo->extraer($apiKey);

        foreach ($movies as $movie) {
            // Verificar si la pelicula o serie esta en la base de datos
            $pelicula = Peliculas::where('id', $movie['id'])->first();

            // Si la película o serie no existe en la base de datos, la ingresamos
            if (!$pelicula) {
                $pelicula = new Peliculas();
                $pelicula->id = $movie['id'];
                $pelicula->delete();
            }
        }
    }
}