<?php
require_once '../modelo/database.php';
require_once '../modelo/peliculas.php';
// Verificar si la conexión está establecida
$conn = new Database();
$conectar = $conn->getConnection();
$peliculas = new Peliculas($conectar);

// URL de la API de Mercado Libre
$url = "https://api.themoviedb.org/3/search/movie?query=Batman&callback=test&api_key=ec84fd2302154d2c26b0d499ac819ce8";

// Obtener datos de la API
$response = file_get_contents($url);

// Decodificar la respuesta JSON
$data = json_decode($response, true);

// Verificar si hay datos
if (!empty($data['results'])) {
  // Recorrer los datos y guardarlos en la base de datos
  foreach ($data['results'] as $item) {
    $titulo = isset($item['title']) ? $item['title'] : '';
    $descripcion = isset($item['overview']) ? $item['overview'] : '';
    $votos = isset($item['vote_average']) ? $item['vote_average'] : '';
    $imagen = isset($item['backdrop_path']) ? $item['backdrop_path'] : '';

    $movies = $peliculas->insert($data);
    // Insertar datos en la base de datos
  
  }
  // Redirigir a la pantalla principal
  header("Location: ../vista/principal.php");
  exit();
} else {
  echo "No se encontraron datos en la API";
}

// Cerrar conexión

$conn->closeConnection();
?>
