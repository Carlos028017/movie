<?php
namespace repositorio;

interface peliculasInterface{
    public function obtenerTodas();
}