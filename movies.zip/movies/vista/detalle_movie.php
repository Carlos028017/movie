<?php
require_once '../modelo/api.php';
use Modelo\apiModell;

$pelicula = new apiModell();
$video = $pelicula->video($moviid,$apiKey);
?>
