<?php
require_once '../modelo/database.php';
require_once '../modelo/peliculas.php';
require_once '../modelo/conexion.php';

//$conn = new Database();
//$conectar = $conn->getConnection();
$conexion = new film();
echo"<pre>";
$resultado = $conexion->obtenerConexion();
echo"</pre>";
//$peliculas = new Peliculas($conectar);
//$movies = $peliculas->getAll();

//echo '<pre>';
//var_dump($movies);
//echo '</pre>';

